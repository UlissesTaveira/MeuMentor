#ifndef DATABASE_H
#define DATABASE_H

class DataBase
{
public:
    DataBase();
};

#endif // DATABASE_H
