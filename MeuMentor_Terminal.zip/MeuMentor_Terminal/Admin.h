/*************************************************
 * @file Admin.h
 * @author Pedro Augusto Sousa Gonçalves
 * @brief This file represents the Admin
*************************************************/
#ifndef ADMIN_H
#define ADMIN_H

#include <UsuarioIMP.h>

/*************************************************************************************
 *@brief The Admin class represents who can administer the system
*************************************************************************************/

class Admin: public UsuarioIMP{
private:
    /**
         * @brief Construct a new Admin by a obj
         * @param other Admin obj
    */
    Admin(const Admin& other);

    /**
         * @brief This method is overloading the '=' operator, "cloning" from one Admin to another
         * @param other Admin obj to be cloned must be passed
         * @return A Admin is returned that is a clone of what was passed to the method
    */
    Admin& operator=(const Admin& other);

public:
    //Consstructor
    /**
         * @brief Construct a new Admin by Nome, Email and Senha
         * @param Nome string with default value "NO_NAME"
         * @param Email string with default value "NO_EMAIL"
         * @param Senha string with default value "NO_PASSWORD"
         * @param Curso string with default value "NO_CURSO"
         * @param Historico string with default value "NO_HISTORICO"
    */
    Admin(const std::string Nome = "NO_NAME", const std::string Email = "NO_EMAIL", const std::string Senha = "NO_PASSWORD");

    //Destructor
    /**
         * @brief This destructor is a destructor of the class
    */
    virtual ~Admin() override;

    //Other Methods
    /**
         * @brief This method create an Usuario in the database
         * @param Obj Usuario obj must be passed
    */
    virtual void Create_DB(const UsuarioIMP& Obj) override;
    /**
         * @brief This method update an Usuario in the database
         * @param Obj Usuario obj must be passed
    */
    virtual void Update_DB(const UsuarioIMP& Obj) override;
    /**
         * @brief This method delete an Usuario in the database
         * @param Obj Usuario obj must be passed
    */
    virtual void Delete_DB(const UsuarioIMP& Obj) override;

};


#endif // ADMIN_H
