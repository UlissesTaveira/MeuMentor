/*************************************************
 * @file Mentor.h
 * @author Pedro Augusto Sousa Gonçalves
 * @brief This file represents the Mentor
*************************************************/
#ifndef MENTOR_H
#define MENTOR_H

#include <UsuarioIMP.h>

/*************************************************************************************
 *@brief The Mentor class represnts the students who need help and who want offer help
*************************************************************************************/

class Mentor: public UsuarioIMP{
private:
    /**
         * @brief Construct a new Mentor by a obj
         * @param other Mentor obj
    */
    Mentor(const Mentor& other);

    /**
         * @brief This method is overloading the '=' operator, "cloning" from one Mentor to another
         * @param other Mentor obj to be cloned must be passed
         * @return A Mentor is returned that is a clone of what was passed to the method
    */
    Mentor& operator=(const Mentor& other);

protected:
    std::string Curso; /**< Curso string attribute. */
    std::string Historico_Path; /**< Historico_Path string attribute. */

public:
    //Consstructor
    /**
         * @brief Construct a new Mentor by Nome, Email, Senha, Curso and Historico
         * @param Nome string with default value "NO_NAME"
         * @param Email string with default value "NO_EMAIL"
         * @param Senha string with default value "NO_PASSWORD"
         * @param Curso string with default value "NO_CURSO"
         * @param Historico string with default value "NO_HISTORICO"
    */
    Mentor(const std::string Nome = "NO_NAME", const std::string Email = "NO_EMAIL", const std::string Senha = "NO_PASSWORD",
           const std::string Curso = "NO_CUSO", const std::string Historico = "NO_HISTORICO");

    //Destructor
    /**
         * @brief This destructor is a destructor of the class
    */
    virtual ~Mentor() override;

    //Getters
    /**
         * @brief This method returns the Curso of an Mentor
         * @return a string containing the Curso is returned
    */
    std::string getCurso() const;

    /**
         * @brief This method returns the Historico of an Mentor
         * @return a string containing the Historico is returned
    */
    std::string getHistorico() const;

    //Setters
    /**
         * @brief This method assigns a string to Curso of an Mentor
         * @param Curso string must be passed to the method
    */
    void setCurso(const std::string Curso);

    /**
         * @brief This method assigns a string to Historico of an Mentor
         * @param Historico string must be passed to the method
    */
    void setHistorico(const std::string Historico);

    //Other Methods
    /**
         * @brief This method create an Usuario in the database
         * @param Obj Usuario obj must be passed
    */
    virtual void Create_DB(const UsuarioIMP& Obj) override;
    /**
         * @brief This method update an Usuario in the database
         * @param Obj Usuario obj must be passed
    */
    virtual void Update_DB(const UsuarioIMP& Obj) override;
    /**
         * @brief This method delete an Usuario in the database
         * @param Obj Usuario obj must be passed
    */
    virtual void Delete_DB(const UsuarioIMP& Obj) override;

};

#endif // MENTOR_H
