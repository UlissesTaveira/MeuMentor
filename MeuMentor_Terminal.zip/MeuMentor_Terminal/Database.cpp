#include "Database.h"

DataBase::DataBase() {}
