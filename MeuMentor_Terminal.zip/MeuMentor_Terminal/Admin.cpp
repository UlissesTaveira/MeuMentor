#include "Admin.h"

Admin::Admin() {}
