#include "UsuarioIMP.h"

UsuarioIMP::UsuarioIMP() {}
