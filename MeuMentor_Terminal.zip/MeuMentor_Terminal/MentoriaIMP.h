#ifndef MENTORIAIMP_H
#define MENTORIAIMP_H

class MentoriaIMP
{
public:
    MentoriaIMP();
};

#endif // MENTORIAIMP_H
