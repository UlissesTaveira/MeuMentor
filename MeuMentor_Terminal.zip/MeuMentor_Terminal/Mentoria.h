/*************************************************
 * @file Mentor.h
 * @author Pedro Augusto Sousa Gonçalves
 * @brief This file represents the Mentor
*************************************************/
#ifndef MENTORIA_H
#define MENTORIA_H

#include <string>

/************************************************************
 *@brief The Mentoria class represents the  mentoring classes
************************************************************/

class Mentoria{
private:
    /**
         * @brief Construct a new Mentoria by a obj
         * @param other Mentoria obj
    */
    Mentoria(const Mentoria& other);

    /**
         * @brief This method is overloading the '=' operator, "cloning" from one Mentoria to another
         * @param other Mentoria obj to be cloned must be passed
         * @return A Mentoria is returned that is a clone of what was passed to the method
    */
    Mentoria& operator=(const Mentoria& other);

protected:
    std::string Codigo; /**< Codigo string attribute. */
    std::string Data; /**< Data string attribute. */
    double Valor; /**< Valor double attribute. */

public:
    // Constructor
    /**
         * @brief Construct a new Mentoria by Codigo, Data and Valor
         * @param Codigo string with default value "NO_CODE"
         * @param Data string with default value "NO_DATE"
         * @param Valor double with default value 0.0
    */
    Mentoria(const std::string Codigo = "NO_CODE", const std::string Data = "NO_DATE", const double Valor = 0.0);

    //Destructor
    /**
         * @brief This destructor is a destructor of the class
    */
    virtual ~Mentoria();

    // Getters
    /**
         * @brief This method returns the Codigo of an Mentoria
         * @return a string containing the Codigo is returned
    */
    std::string getCodigo() const;
    /**
         * @brief This method returns the Data of an Mentoria
         * @return a string containing the Data is returned
    */
    std::string getData() const;
    /**
         * @brief This method returns the Valor of an Mentoria
         * @return a double containing the Data is returned
    */
    double getValor() const;

    // Setters
    /**
         * @brief This method assigns a string to Codigo of an Mentoria
         * @param Codigo string must be passed to the method
    */
    void setCodigo(const std::string& codigo);
    /**
         * @brief This method assigns a string to Data of an Mentoria
         * @param Data string must be passed to the method
    */
    void setData(const std::string& data);
    /**
         * @brief This method assigns a double to Valor of an Mentoria
         * @param Valor double must be passed to the method
    */
    void setValor(double valor);
};

#endif // MENTORIA_H
