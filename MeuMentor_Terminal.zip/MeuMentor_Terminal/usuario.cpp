#include "usuario.h"

Usuario::Usuario() {}
