#include "MyVensimIMP.hpp"
#include "SystemIMP.hpp"
#include "ModelIMP.hpp"

MyVensimIMP::MyVensimIMP(){}

MyVensimIMP::~MyVensimIMP() {
    models.clear();
    flows.clear();
    systems.clear();
}

MyVensim* MyVensim::getMyVensimInstance(){
    return MyVensimIMP::createMyVensim(); 
}

MyVensim* MyVensimIMP::createMyVensim(){
    MyVensim* m = new MyVensimIMP();
    return m;
}

System* MyVensimIMP::createSystem(const std::string& name, const double& value){
    System* s = new SystemIMP(name, value);
    add(s);
    return s;
}

Model* MyVensimIMP::createModel(const std::string& name, const int& startTime, const int& endTime){
    Model* m = new ModelIMP(name, startTime, endTime);
    add(m);
    return m;
}

//Geters e seters
//Vector
std::vector<System*> MyVensimIMP::getSystems() const { return systems; }
std::vector<Flow*> MyVensimIMP::getFlows() const { return flows; }
std::vector<Model*> MyVensimIMP::getModels() const { return models; }
void MyVensimIMP::setSystems(const std::vector<System*> systems) { this->systems.clear(); for(auto i : systems) this->systems.push_back(i); }
void MyVensimIMP::setFlows(const std::vector<Flow*> flows) { this->flows.clear(); for(auto i : flows) this->flows.push_back(i); }
void MyVensimIMP::setModels(const std::vector<Model*> models) { { this->models.clear(); for(auto i : models) this->models.push_back(i); } }

//add
void MyVensimIMP::add(System* system){ systems.push_back(system); }
void MyVensimIMP::add(Flow* flow){ flows.push_back(flow); }
void MyVensimIMP::add(Model* model){ models.push_back(model); };

//remove
bool MyVensimIMP::rmv(const System* system){
    for(systemIterator i = systems.begin(); i < systems.end(); i++)
        if(*i == system){
            systems.erase(i);
            return true;
        }
    return false; 
}
bool MyVensimIMP::rmv(const Flow* flow){
    for(flowIterator i = flows.begin(); i < flows.end(); i++)
        if(*i == flow){
            flows.erase(i);
            return true;
        }
    return false; 
}
bool MyVensimIMP::rmv(const Model* model){
    for(modelIterator i = models.begin(); i < models.end(); i++)
        if(*i == model){
            models.erase(i);
            return true;
        }
    return false; 
}

bool MyVensimIMP::run(){
    if(models.empty()) return false;
    for(auto i : models) if(!(i->run())) return false;
    return true;
}

